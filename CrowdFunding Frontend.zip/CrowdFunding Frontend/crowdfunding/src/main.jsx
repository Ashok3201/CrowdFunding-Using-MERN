import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom"; // Ensure Router is only here
import App from "./App";
import "bootstrap/dist/css/bootstrap.min.css";      // Ensure Bootstrap is imported
import "bootstrap/dist/js/bootstrap.bundle.min.js"; // Ensure JS features like Carousel work


ReactDOM.createRoot(document.getElementById("root")).render(
  <BrowserRouter> {/* ✅ Router should be only here */}
    <App />
  </BrowserRouter>
);
