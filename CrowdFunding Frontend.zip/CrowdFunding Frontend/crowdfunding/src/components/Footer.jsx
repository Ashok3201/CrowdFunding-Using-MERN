import "bootstrap/dist/css/bootstrap.min.css"; // Ensure Bootstrap is imported
import "bootstrap-icons/font/bootstrap-icons.css"; // Import Bootstrap Icons

const Footer = () => {
  return (
    <footer className="bg-dark text-white py-5">
      <div className="container">
        <div className="row">
          {/* Brand & About */}
          <div className="col-lg-4 col-md-6 mb-4">
            <h4 className="fw-bold">🚀 CrowdFund</h4>
            <p className="text-muted">
              Empowering innovators and creators to bring their ideas to life through crowdfunding.
            </p>
          </div>

          {/* Quick Links */}
          <div className="col-lg-2 col-md-3 mb-4">
            <h5 className="fw-bold">Quick Links</h5>
            <ul className="list-unstyled">
              <li><a href="/" className="text-white text-decoration-none">🏠 Home</a></li>
              <li><a href="/about" className="text-white text-decoration-none">ℹ️ About</a></li>
              <li><a href="/campaigns" className="text-white text-decoration-none">📢 Campaigns</a></li>
              <li><a href="/contact" className="text-white text-decoration-none">📞 Contact</a></li>
            </ul>
          </div>

          {/* Resources */}
          <div className="col-lg-2 col-md-3 mb-4">
            <h5 className="fw-bold">Resources</h5>
            <ul className="list-unstyled">
              <li><a href="/faq" className="text-white text-decoration-none">❓ FAQ</a></li>
              <li><a href="/privacy" className="text-white text-decoration-none">🔒 Privacy</a></li>
              <li><a href="/terms" className="text-white text-decoration-none">📜 Terms</a></li>
            </ul>
          </div>

          {/* Social Media */}
          <div className="col-lg-4 col-md-12 text-lg-end">
            <h5 className="fw-bold">Follow Us</h5>
            <div className="d-flex justify-content-lg-end gap-3">
              <a href="#" className="text-white fs-4"><i className="bi bi-facebook"></i></a>
              <a href="#" className="text-white fs-4"><i className="bi bi-twitter"></i></a>
              <a href="#" className="text-white fs-4"><i className="bi bi-instagram"></i></a>
              <a href="#" className="text-white fs-4"><i className="bi bi-linkedin"></i></a>
              <a href="#" className="text-white fs-4"><i className="bi bi-youtube"></i></a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="text-center mt-4">
          <p className="text-muted mb-0">
            &copy; {new Date().getFullYear()} CrowdFund. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
