import "bootstrap/dist/css/bootstrap.min.css"; // Import Bootstrap

const About = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-primary text-white text-center py-5">
        <div className="container">
          <h1 className="fw-bold">Empowering Ideas, Connecting Communities</h1>
          <p className="lead">Join us in revolutionizing crowdfunding with transparency and trust.</p>
        </div>
      </section>

      {/* About Section */}
      <section className="container my-5">
        <div className="row align-items-center">
          <div className="col-md-6">
            <h2 className="fw-bold text-primary">Who We Are</h2>
            <p className="text-muted">
              CrowdFund is a next-generation crowdfunding platform designed to help innovators and creators bring their ideas to life. 
              Our mission is to provide a secure, user-friendly, and transparent environment where campaigners can showcase their projects and backers can support meaningful initiatives.
            </p>
          </div>
          <div className="col-md-6 text-center">
            <img src="/assets/about-image.jpg" alt="About Us" className="img-fluid rounded shadow" />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-light py-5">
        <div className="container text-center">
          <h2 className="fw-bold">Why Choose CrowdFund?</h2>
          <div className="row mt-4">
            <div className="col-md-4">
              <div className="card p-4 border-0 shadow">
                <h3>🔒 Secure & Transparent</h3>
                <p>We ensure safe transactions with the latest security measures.</p>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card p-4 border-0 shadow">
                <h3>🚀 Easy Campaign Creation</h3>
                <p>Our intuitive platform makes it simple to launch your campaign.</p>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card p-4 border-0 shadow">
                <h3>🌍 Global Reach</h3>
                <p>Connect with backers worldwide to bring your ideas to life.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
