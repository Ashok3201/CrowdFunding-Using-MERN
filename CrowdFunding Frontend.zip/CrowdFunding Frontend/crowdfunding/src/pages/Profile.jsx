import { useState } from "react";

const Profile = () => {
  const [name, setName] = useState("John Doe");
  const [email, setEmail] = useState("john@example.com");
  const [bio, setBio] = useState("Passionate about crowdfunding.");
  const [profilePic, setProfilePic] = useState("https://via.placeholder.com/150");

  const handleUpdate = (e) => {
    e.preventDefault();
    alert("Profile updated successfully!");
  };

  return (
    <div className="container my-5">
      <h2 className="text-center">My Profile</h2>

      <div className="card p-4 shadow-sm mx-auto" style={{ maxWidth: "500px" }}>
        <div className="text-center">
          <img src={profilePic} alt="Profile" className="rounded-circle mb-3" width="100" />
        </div>

        <form onSubmit={handleUpdate}>
          <div className="mb-3">
            <label className="form-label">Full Name</label>
            <input type="text" className="form-control" value={name} onChange={(e) => setName(e.target.value)} />
          </div>

          <div className="mb-3">
            <label className="form-label">Email</label>
            <input type="email" className="form-control" value={email} disabled />
          </div>

          <div className="mb-3">
            <label className="form-label">Bio</label>
            <textarea className="form-control" rows="3" value={bio} onChange={(e) => setBio(e.target.value)}></textarea>
          </div>

          <button type="submit" className="btn btn-primary w-100">Update Profile</button>
        </form>
      </div>
    </div>
  );
};

export default Profile;
