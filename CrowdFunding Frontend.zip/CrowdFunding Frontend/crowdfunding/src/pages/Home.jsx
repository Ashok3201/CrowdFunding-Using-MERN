import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div>
      {/* Hero Section with Image Slider */}
      <div id="heroCarousel" className="carousel slide carousel-fade" data-bs-ride="carousel">
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img src="/assets/hero1.jpg" className="d-block w-100" alt="Startup" />
            <div className="carousel-caption d-flex flex-column justify-content-center align-items-center">
              <h1 className="display-4 fw-bold">Empower Ideas with Crowdfunding</h1>
              <p className="lead">Launch your campaign and bring your vision to life.</p>
              <Link to="/signup" className="btn btn-primary btn-lg mt-3">Start a Campaign</Link>
            </div>
          </div>

          <div className="carousel-item">
            <img src="/assets/hero2.jpg" className="d-block w-100" alt="Finance" />
            <div className="carousel-caption d-flex flex-column justify-content-center align-items-center">
              <h1 className="display-4 fw-bold">Secure & Transparent Transactions</h1>
              <p className="lead">Our platform ensures seamless financial support.</p>
              <Link to="/signup" className="btn btn-primary btn-lg mt-3">Join Now</Link>
            </div>
          </div>

          <div className="carousel-item">
            <img src="/assets/hero3.jpg" className="d-block w-100" alt="Community" />
            <div className="carousel-caption d-flex flex-column justify-content-center align-items-center">
              <h1 className="display-4 fw-bold">Support and Grow Together</h1>
              <p className="lead">Back innovative projects and be part of something great.</p>
              <Link to="/campaigns" className="btn btn-primary btn-lg mt-3">Explore Campaigns</Link>
            </div>
          </div>
        </div>

        {/* Carousel Controls */}
        <button className="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
        </button>
      </div>
    
    {/* Features Section */}
    <section className="features py-5">
        <div className="container text-center">
          <h2 className="fw-bold">Why Choose Our Platform?</h2>
          <div className="row mt-4">
            <div className="col-md-4">
              <h4>💰 Secure Payments</h4>
              <p>Our trusted payment gateway ensures smooth transactions.</p>
            </div>
            <div className="col-md-4">
              <h4>📊 Transparent Analytics</h4>
              <p>Track campaign performance with real-time insights.</p>
            </div>
            <div className="col-md-4">
              <h4>🚀 Easy Campaign Setup</h4>
              <p>Launch your campaign in just a few minutes.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Trending Campaigns */}
      <section className="trending bg-light py-5">
        <div className="container text-center">
          <h2 className="fw-bold">Trending Campaigns</h2>
          <div className="row mt-4">
            <div className="col-md-4">
              <div className="card">
                <img src="/assets/1.jpg" className="card-img-top" alt="Campaign 1" />
                <div className="card-body">
                  <h5 className="card-title">Tech Innovation</h5>
                  <p className="card-text">A revolutionary new gadget that changes the game.</p>
                  <Link to="/campaigns" className="btn btn-primary">View</Link>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card">
                <img src="/assets/2.jpeg" className="card-img-top" alt="Campaign 2" />
                <div className="card-body">
                  <h5 className="card-title">Medical Aid</h5>
                  <p className="card-text">Helping communities with essential medical support.</p>
                  <Link to="/campaigns" className="btn btn-primary">View</Link>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card">
                <img src="/assets/3.jpg" className="card-img-top" alt="Campaign 3" />
                <div className="card-body">
                  <h5 className="card-title">Education for All</h5>
                  <p className="card-text">Empowering children with quality education opportunities.</p>
                  <Link to="/campaigns" className="btn btn-primary">View</Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>

  );
};

export default Home;
