import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/auth/login", { email, password });
      localStorage.setItem("token", res.data.token);
      alert("Login successful");
      navigate("/dashboard");
    } catch (error) {
      alert("Invalid credentials");
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center vh-100 bg-light">
      <div className="card p-4 shadow-lg border-0 rounded-4" style={{ width: "400px" }}>
        <h2 className="text-center mb-3">Welcome Back!</h2>
        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <input type="email" className="form-control rounded-pill" placeholder="Email" onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="mb-3">
            <input type="password" className="form-control rounded-pill" placeholder="Password" onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <button type="submit" className="btn btn-primary w-100 rounded-pill">Login</button>
        </form>
        <p className="text-center mt-3">
          New user? <a href="/signup" className="text-decoration-none">Create an account</a>
        </p>
      </div>
    </div>
  );
};

export default Login;
