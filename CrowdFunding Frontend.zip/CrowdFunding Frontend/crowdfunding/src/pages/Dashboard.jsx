import { Link } from "react-router-dom";

const Dashboard = () => {
  return (
    <div className="container my-5">
      <h2 className="text-center mb-4">Welcome to Your Dashboard</h2>

      <div className="row">
        {/* Fundraiser Section */}
        <div className="col-md-6">
          <div className="card p-4 shadow-sm">
            <h4>Manage Your Campaigns</h4>
            <p>Create, track, and edit your crowdfunding campaigns.</p>
            <Link to="/create-campaign" className="btn btn-primary">
              Create New Campaign
            </Link>
            <Link to="/my-campaigns" className="btn btn-outline-secondary ms-2">
              View My Campaigns
            </Link>
          </div>
        </div>

        {/* Backer Section */}
        <div className="col-md-6">
          <div className="card p-4 shadow-sm">
            <h4>Explore & Support Campaigns</h4>
            <p>Find trending projects and contribute to innovative ideas.</p>
            <Link to="/explore" className="btn btn-success">
              Explore Campaigns
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
